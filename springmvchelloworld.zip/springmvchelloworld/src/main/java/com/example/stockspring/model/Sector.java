package com.example.stockspring.model;

public class Sector {

}
